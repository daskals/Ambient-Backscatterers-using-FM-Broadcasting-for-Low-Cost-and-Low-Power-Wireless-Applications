
/********************************************************************************
 * - myClocks.c			('FR5969 Launchpad)										*
 * - Author: Spiros Daskalakis													*
 * - Version: 10.0																*
 ********************************************************************************/

//***** Header Files **********************************************************
#include <driverlib.h>
#include "myClocks.h"

#include "STSM_main_v10.h"

//***** Defines ***************************************************************
// See additional #defines in 'myClocks.h'


//***** Global Variables ******************************************************
uint32_t myACLK  = 0;
uint32_t mySMCLK = 0;
uint32_t myMCLK  = 0;


//***** initClocks ************************************************************
void initClocks(void) {

    //**************************************************************************
    // Configure Oscillators
    //**************************************************************************

    // Set DCO to run at 1MHz
    CS_setDCOFreq(
            CS_DCORSEL_0,                                                       // Set Frequency range (DCOR)
            CS_DCOFSEL_0                                                        // Set Frequency (DCOF)
    );

    //**************************************************************************
    // Configure Clocks
    //**************************************************************************
    // Set ACLK to use LFXT as its oscillator source (32KHz)
    // With a 32KHz crystal and a divide by 1, ACLK should run at that rate
    CS_initClockSignal(
            CS_ACLK,                   //ACLK = VLO                              // Clock you're configuring
			CS_LFXTCLK_SELECT,                                                  // Clock source (CS_VLOCLK_SELECT,   //VLO (9kHz))
            CS_CLOCK_DIVIDER_1                                                  // Divide down clock source by this much
    );

    // Set SMCLK to use DCO as its oscillator source (DCO was configured earlier in this function for 1MHz)
    CS_initClockSignal(           		//SMCLK = DCO
            CS_SMCLK,                                                           // Clock you're configuring
            CS_DCOCLK_SELECT,                                                   // Clock source
            CS_CLOCK_DIVIDER_1                                                  // Divide down clock source by this much
    );

    // Set MCLK to use DCO as its oscillator source (DCO was configured earlier in this function for 1MHz)
    CS_initClockSignal(					//MCLK = DCO
            CS_MCLK,                                                            // Clock you're configuring
            CS_DCOCLK_SELECT,                                                   // Clock source
            CS_CLOCK_DIVIDER_1                                                  // Divide down clock source by this much
    );


    // Verify that the modified clock settings are as expected
    myACLK  = CS_getACLK();
    mySMCLK = CS_getSMCLK();
    myMCLK  = CS_getMCLK();



    	// Set the LFXT and HFXT crystal frequencies being used so that driverlib
      //   knows how fast they are (needed for the clock 'get' functions)
      CS_setExternalClockSource(
              LF_CRYSTAL_FREQUENCY_IN_HZ,
              HF_CRYSTAL_FREQUENCY_IN_HZ
      );



      // Initialize LFXT crystal oscillator without a timeout. In case of failure
      //   the code remains 'stuck' in this function.
      // For time-out instead of code hang use CS_turnOnLFXTWithTimeout(); see an
      //   example of this in lab_04c_crystals.
      CS_turnOnLFXT( CS_LFXT_DRIVE_0 );


}

