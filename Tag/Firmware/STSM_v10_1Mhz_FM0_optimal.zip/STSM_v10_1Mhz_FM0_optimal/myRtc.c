/********************************************************************************
 * - MyRtc.c			('FR5969 Launchpad)										*
 * - Author: Spiros Daskalakis													*
 * - Version: 10.0																*
 ********************************************************************************/

#include <driverlib.h>
#include "myRTC.h"

//***** initClocks ************************************************************
void Init_RTC()
{

	 //Setup Current Time for Calendar
	     calendar.Seconds    = 0x57;  // 57 58 59...gives an interupt and wake up the microcontroler
	     calendar.Minutes    = 0x30;
	     calendar.Hours      = 0x04;
	     calendar.DayOfWeek  = 0x01;
	     calendar.DayOfMonth = 0x30;
	     calendar.Month      = 0x04;
	     calendar.Year       = 0x2014;


	     // Initialize RTC with the specified Calendar above
	     RTC_B_initCalendar(RTC_B_BASE,
	                        &calendar,
	                        RTC_B_FORMAT_BCD);

	     RTC_B_setCalendarEvent(RTC_B_BASE,
	     		               RTC_B_CALENDAREVENT_MINUTECHANGE // tha xtipisei otan alaxei to lepto- meta to xanasetaro kai paei apo tin arxi
	     		               );

	     RTC_B_clearInterrupt(RTC_B_BASE,
	                          RTC_B_TIME_EVENT_INTERRUPT
	                          );

	     RTC_B_enableInterrupt(RTC_B_BASE,
	                           RTC_B_TIME_EVENT_INTERRUPT
	                           );

	     //Start RTC Clock
	     RTC_B_startClock(RTC_B_BASE);

}
