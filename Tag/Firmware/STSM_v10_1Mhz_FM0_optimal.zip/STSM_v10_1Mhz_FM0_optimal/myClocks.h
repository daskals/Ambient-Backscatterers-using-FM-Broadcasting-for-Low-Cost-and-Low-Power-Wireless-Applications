
/********************************************************************************
 * - myClocks.h			('FR5969 Launchpad)										*
 * - Author: Spiros Daskalakis													*
 * - Version: 10.0																*
 ********************************************************************************/


//***** Prototypes ************************************************************
#ifndef MYV3_UART_CAP_MYCLOCKS_H_
#define MYV3_UART_CAP_MYCLOCKS_H_

//***** Prototypes ************************************************************
void initClocks(void);

//***** Defines ***************************************************************
#define LF_CRYSTAL_FREQUENCY_IN_HZ     32768
#define HF_CRYSTAL_FREQUENCY_IN_HZ     0                                        // FR5969 Launchpad does not ship with HF Crystal populated

#define myMCLK_FREQUENCY_IN_HZ         1000000
#define mySMCLK_FREQUENCY_IN_HZ        1000000
#define myACLK_FREQUENCY_IN_HZ         32768

#endif /* MYV3_UART_CAP_MYCLOCKS_H_ */

