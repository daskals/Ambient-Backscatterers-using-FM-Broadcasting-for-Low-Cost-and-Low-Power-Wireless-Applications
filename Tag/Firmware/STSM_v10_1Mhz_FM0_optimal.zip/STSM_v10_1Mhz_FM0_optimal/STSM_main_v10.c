/********************************************************************************
 * - STSM_main_v10.c														    *
 * - Author: Spyridon-Nektarios Daskalakis										*
 * - Version: 10.0																*
 ********************************************************************************/


#include <msp430.h>
#include "driverlib.h"
//////////////////////////////////My libs
#include "myGpio.h"
#include "myClocks.h"
#include "myUart.h"
#include "myRtc.h"
#include "BackscatterCom.h"
#include "stdio.h"
#include "math.h"
#include <stdlib.h>
#include "STSM_main_v10.h"
//------------------------------------------------------------------
// Global Variables
//------------------------------------------------------------------
const int Debug_en=0; 		// enable the uart - the leds- and nop points
const int Sleep_en=0; 		// an to kano 1 den tha douleuei h uart
const int lEDIND=1;  		//  open led for dubug peproses
 // number of
 int SensorID=0;
 //------------------------------------------------------------------
 // UART Strings Variables
 //------------------------------------------------------------------
char gStr1[30];
char gStr2[30];
char gStr3[30];
char gStr4[30];
char gStr5[30];
char gStr6[30];
char gStr7[30];

//-----------------------------------------------------------------------------
// Packet Format
//-----------------------------------------------------------------------------
unsigned char  packet[PACKETLENGTH];
unsigned char  infodata[GEN_MATRIX_ROWS];
unsigned char  *Mypacket="01010"; //16+5+8+16 =45
//-----------------------------------------------------------------------------
// Temperature Sensors Factors
//-----------------------------------------------------------------------------
volatile float FactorA;
volatile float FactorB;
volatile float FactorC;
volatile float FactorD;
//-----------------------------------------------------------------------------
// Temperature Values
//-----------------------------------------------------------------------------
volatile float TemporC1;
volatile float TemporC2;
volatile float TempDiff;
//-----------------------------------------------------------------------------
// ADC Temporary Values
//-----------------------------------------------------------------------------
unsigned int data0 = 0;
unsigned int data1 = 0;
unsigned int data2 = 0;
unsigned int data3 = 0;
//-----------------------------------------------------------------------------
// ADC Voltage Values
//-----------------------------------------------------------------------------
int16_t CalmVolt0;
int16_t CalmVolt1;
int16_t CalmVolt2;
int16_t VBatt;


#if defined(__IAR_SYSTEMS_ICC__)
#pragma location = 0x9000
__no_init uint16_t dataArray[12289];
#endif
int _system_pre_init(void)
{
    // Stop Watchdog timer
    WDT_A_hold(__MSP430_BASEADDRESS_WDT_A__);     // Stop WDT

    /*==================================*/
    /* Choose if segment initialization */
    /* should be done or not. */
    /* Return: 0 to omit initialization */
    /* 1 to run initialization */
    /*==================================*/
    return 1;
}

int main(void)
{
	int i=0;

	 // Disable the GPIO power-on default high-impedance mode to activate
	 // previously configured port settings
	 PM5CTL0 &= ~LOCKLPM5;


			if(Sleep_en==1) //  enable and disable the RTC at myGpio
	        {
				Init_RTC();
	        }
	        initGPIO();  // Initialize GPIO
	        initClocks(); // Initialize clocks

	        	    if (SYSRSTIV == SYSRSTIV_LPM5WU) // Check if a wakeup from LPMx.5
	        	    {
	        	    	 __no_operation();
	        	    }
	        	    else
	        	    {
	        	    	// Board initializations
	        	    	 // Init board & RTC, then enter LPM3.5
	        	    		int xi;
	        	    		for (xi=2;xi>0;xi--)
	        	    		{
	        	    			//GPIO_toggleOutputOnPin(GPIO_PORT_P4, GPIO_PIN6); //tin proti fora anavei to kokkino kai mpainei se sleep
	        	    			 if (lEDIND==1) {
	        	    				 	 GPIO_toggleOutputOnPin(GPIO_PORT_P1, GPIO_PIN0);
	        	    				 	 __delay_cycles(200000);
	        	    			 }
	        	    		}
	        	    }

	        	    if(Debug_en==1) // enable and disable the uart at myGpio
	        	    {
	        	    	// Initialize UART (for backchannel communications)
	        	    	if ( myUart_init( BACKCHANNEL_UART, 9600, &myUart_Param_9600_8N1_ACLK32Kz ) >> 0)
	        	    	{}

	        	    }

	        	    	// Enable interrupts globally
	        	    	// __enable_interrupt();

                    while (1)
                    {
                    	              GPIO_setOutputHighOnPin(GPIO_PORT_P1, GPIO_PIN2); //open VDD power Supply for the sensors ->pin P1.2

                	 	 	 	 	 	InitMyADC();
                	 	        	    myvref2V();
                	 	        	    InitMyTimerA();
                	 	        	    getSensorData();
                	 	        	    //CaltulateTempDif();

                	 	        	    //-------------------Send packets with Sensor Measurements------------------------
                	 	        	   //SendFIXEDBits();

                	 	        	    SensorID=1;
                	 	        	    CalmVolt0=965;
                	 	        	    createPacket(packet,SensorID, CalmVolt0); //Packet with data from sensor 1
                	 	        	    backscatter_transmit_packet(packet,PACKETLENGTH);
                	 	        	    //SensorID=2;
                	 	        	    //createPacket(SensorID, CalmVolt1); //Packet with data from sensor 2
                	 	        	    //backscatter_transmit_packet(packet,PACKETLENGTH);
                	 	        	    //SensorID=3;
                	 	        	    //createPacket(SensorID, VBatt);    //Packet with data from sensor 3
                	 	        	    //backscatter_transmit_packet(packet,PACKETLENGTH);
                	 	        	    //---------------------------------------------------------------


                  	  	  	  if(Debug_en==1) // energopoiei kai apenergopoiei thn uart sto myGpio
                              {

                  	  	  		  	  	  	myUart_writeBuf( BACKCHANNEL_UART, "!*--------------START-------------*!", NULL, CRLF );
                                  	 	 	sprintf(gStr1,"ADC P1.3: %d mV", CalmVolt0);
                                  	 	 	 myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)gStr1, NULL, CRLF );
                                  	 	 	__delay_cycles(1000000);
                                  	 	    sprintf(gStr2,"ADC P1.4: %d mV", CalmVolt1);
                                  	 	    myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)gStr2, NULL, CRLF );
                                  	 	    __delay_cycles(1000000);

                                  	 	    sprintf(gStr3,"ADC P1.5: %d mV", CalmVolt2);
                                  	 	    myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)gStr3, NULL, CRLF );
                                  	 	    __delay_cycles(1000000);

                                  	 	    sprintf(gStr4,"ADC VBat: %d mV", VBatt);
                                  	 	    myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)gStr4, NULL, CRLF );
                                  	 	    __delay_cycles(1000000);

                                  	 	    //sprintf(gStr5,"TempC1: %d,%dC", (int) TemporC1, ((int)((TemporC1 - floor(TemporC1)) * 1000.0)));
                                  	 	 	//myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)gStr5, NULL, CRLF );
                                  	 	    //__delay_cycles(1000000);

                                  	  	    //sprintf(gStr6,"TempC2: %d,%dC", (int) TemporC2, ((int)((TemporC2 - floor(TemporC2)) * 1000.0)));
                                  	  	    //myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)gStr6, NULL, CRLF );
                                      	    //__delay_cycles(1000000);

                       	 	 	    	    //sprintf(gStr7,"TempDiffC: %d,%dC", (int) TempDiff, ((int)((TempDiff - floor(TempDiff)) * 1000.0)));
                       	 	 	    	    //myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)gStr7, NULL, CRLF );
                           	   	    	    //__delay_cycles(1000000);
                           	   	    	    myUart_writeBuf( BACKCHANNEL_UART, "***PACKET BITS***", NULL, CRLF );
                           	   	    	    myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)packet, NULL, CRLF );
                           	   	    	   __delay_cycles(1000000);
                           	   	    	    myUart_writeBuf( BACKCHANNEL_UART, "***DATA BITS (16)***", NULL, CRLF );
                           	   	    	    myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)infodata, NULL, CRLF );
                           	   	    	   __delay_cycles(1000000);
                                }

                  	 //__delay_cycles(1); //for 200 us
                  	//__delay_cycles(800); //for 500 us kai 400 us
                  	__delay_cycles(1000); //for 1ms
                  	//__delay_cycles(700000); //for 5ms
                  	//__delay_cycles(1500000); //for 10ms

                  	  	  	 if (lEDIND==1)
                  	  	  	 {
                  	  	  	  //open the green led P0.1 to indicate the  finish of the program
                  	  	  		 	 for (i=2;i>0;i--)
                  	  	  		 	 {
                  	  	      	           	 GPIO_toggleOutputOnPin(GPIO_PORT_P1, GPIO_PIN0);
                        	   	          __delay_cycles(100000); //for 1 ms & 10 ms
                        	   	        //__delay_cycles(44000); //for 400 us & 500 ms
                  	  	      	       //__delay_cycles(18000); //for 200 us
                  	  	  		 	 }
                  	  	  	 }

                  if(Sleep_en==1) // energopoiei kai apenergopoiei thn uart sto myGpio
                  {
                             enterLPM35();
                  }

                 }// end of while
} // end of main



void InitMyADC()
{
	//Initialize the ADC12B Module
		             /*
		              * Base address of ADC12B Module
		              * Use internal ADC12B bit as sample/hold signal to start conversion
		              * USE MODOSC 5MHZ Digital Oscillator as clock source
		              * Use default clock divider/pre-divider of 1
		              * Not use internal channel
		              */
		             ADC12_B_initParam initParam = {0};
		             initParam.sampleHoldSignalSourceSelect = ADC12_B_SAMPLEHOLDSOURCE_SC;
		             initParam.clockSourceSelect = ADC12_B_CLOCKSOURCE_ADC12OSC;  //Use ADC12OSC (MODOSC) as clock
		             initParam.clockSourceDivider = ADC12_B_CLOCKDIVIDER_1;
		             initParam.clockSourcePredivider = ADC12_B_CLOCKPREDIVIDER__1;
		             initParam.internalChannelMap = ADC12_B_BATTMAP|ADC12_B_NOINTCH;
		             ADC12_B_init(ADC12_B_BASE, &initParam);

		             //Enable the ADC12B module
		                 ADC12_B_enable(ADC12_B_BASE);

		                 /*
		                  * Base address of ADC12B Module
		                  * For memory buffers 0-7 sample/hold for 64 clock cycles
		                  * For memory buffers 8-15 sample/hold for 4 clock cycles (default)
		                  * Disable Multiple Sampling
		                  */
		                 //ADC12_B_setupSamplingTimer(ADC12_B_BASE,ADC12_B_CYCLEHOLD_16_CYCLES,ADC12_B_CYCLEHOLD_4_CYCLES,ADC12_B_MULTIPLESAMPLESENABLE);
		                 // Sets up the sampling timer pulse mode
		                    ADC12_B_setupSamplingTimer(ADC12_B_BASE, ADC12_B_CYCLEHOLD_128_CYCLES,ADC12_B_CYCLEHOLD_128_CYCLES,ADC12_B_MULTIPLESAMPLESENABLE);
		                    //ADC12_B_setupSamplingTimer(ADC12_B_BASE, ADC12_B_CYCLEHOLD_256_CYCLES,ADC12_B_CYCLEHOLD_256_CYCLES, ADC12_B_MULTIPLESAMPLESENABLE);


		                 //Configure Memory Buffer
		                 /*
		                  * Base address of the ADC12B Module
		                  * Configure memory buffer 0
		                  * Map input A1 to memory buffer 0
		                  * Vref+ = AVcc
		                  * Vref- = AVss
		                  * Memory buffer 0 is not the end of a sequence
		                  */
		                 ADC12_B_configureMemoryParam configureMemoryParam = {0};
		                 configureMemoryParam.memoryBufferControlIndex = ADC12_B_MEMORY_0;
		                 configureMemoryParam.inputSourceSelect = ADC12_B_INPUT_A3; //P1.3/A3
		                 configureMemoryParam.refVoltageSourceSelect = ADC12_B_VREFPOS_INTBUF_VREFNEG_VSS; //ADC12_B_VREFPOS_AVCC_VREFNEG_VSS;
		                 configureMemoryParam.endOfSequence = ADC12_B_NOTENDOFSEQUENCE; //Is not the end of a sequence
		                 configureMemoryParam.windowComparatorSelect = ADC12_B_WINDOW_COMPARATOR_DISABLE; //Disable Window Comparator
		                 configureMemoryParam.differentialModeSelect = ADC12_B_DIFFERENTIAL_MODE_DISABLE; //Disable Differential mode
		                 ADC12_B_configureMemory(ADC12_B_BASE, &configureMemoryParam);


		                configureMemoryParam.memoryBufferControlIndex = ADC12_B_MEMORY_1;
		                configureMemoryParam.inputSourceSelect = ADC12_B_INPUT_A4; //P1.4/A4
		                configureMemoryParam.refVoltageSourceSelect = ADC12_B_VREFPOS_INTBUF_VREFNEG_VSS; //ADC12_B_VREFPOS_AVCC_VREFNEG_VSS;
		                configureMemoryParam.endOfSequence = ADC12_B_NOTENDOFSEQUENCE; //Is not the end of a sequence
		                configureMemoryParam.windowComparatorSelect = ADC12_B_WINDOW_COMPARATOR_DISABLE; //Disable Window Comparator
		                configureMemoryParam.differentialModeSelect = ADC12_B_DIFFERENTIAL_MODE_DISABLE; //Disable Differential mode
		                ADC12_B_configureMemory(ADC12_B_BASE, &configureMemoryParam);


		                configureMemoryParam.memoryBufferControlIndex = ADC12_B_MEMORY_2;
		                configureMemoryParam.inputSourceSelect = ADC12_B_INPUT_A5; // P1.5/A5
		                configureMemoryParam.refVoltageSourceSelect = ADC12_B_VREFPOS_INTBUF_VREFNEG_VSS; //ADC12_B_VREFPOS_AVCC_VREFNEG_VSS;
		                configureMemoryParam.endOfSequence = ADC12_B_NOTENDOFSEQUENCE; //Is not the end of a sequence
		                configureMemoryParam.windowComparatorSelect = ADC12_B_WINDOW_COMPARATOR_DISABLE; //Disable Window Comparator
		                configureMemoryParam.differentialModeSelect = ADC12_B_DIFFERENTIAL_MODE_DISABLE; //Disable Differential mode
		                ADC12_B_configureMemory(ADC12_B_BASE, &configureMemoryParam);


		                configureMemoryParam.memoryBufferControlIndex = ADC12_B_MEMORY_3;
		                configureMemoryParam.inputSourceSelect = ADC12_B_INPUT_BATMAP;
		                configureMemoryParam.refVoltageSourceSelect = ADC12_B_VREFPOS_INTBUF_VREFNEG_VSS; //ADC12_B_VREFPOS_AVCC_VREFNEG_VSS;
		                configureMemoryParam.endOfSequence = ADC12_B_ENDOFSEQUENCE; //Is the end of a sequence
		                configureMemoryParam.windowComparatorSelect = ADC12_B_WINDOW_COMPARATOR_DISABLE; //Disable Window Comparator
		                configureMemoryParam.differentialModeSelect = ADC12_B_DIFFERENTIAL_MODE_DISABLE; //Disable Differential mode
		                ADC12_B_configureMemory(ADC12_B_BASE, &configureMemoryParam);



		                 //Clear interrupt flags
		                 ADC12_B_clearInterrupt(ADC12_B_BASE,    //ADC12B
		                         0,                              //Interrupt Flag Register 0
		                         ADC12_B_IFG3);                  //Clear Mem Buf 0 flag

		                 //Enable memory buffer 0 interrupt
		                 ADC12_B_enableInterrupt(ADC12_B_BASE,   //ADC12B
		                         ADC12_B_IE3,                    //Enable Mem Buf 0 interrupt
		                         0,                              //No interrupts in ADC12IER1
		                         0);                             //No interrupts in ADC12IER
}

/*
 * Enter Low Power Mode 3.5
 */
void enterLPM35()
{
    // Request the disabling of the core voltage regulator when device enters
    // LPM3 (or LPM4) so that we can effectively enter LPM3.5 (or LPM4.5).
    PMM_turnOffRegulator();

         // Enter LPM3.5 mode with interrupts enabled. Note that this operation does
        // not return. The LPM3.5 will exit through a RESET event, resulting in a
        // re-start of the code.
    __bis_SR_register(LPM4_bits + GIE);
    __no_operation();
}


void myvref1_2V()
{
		//If ref generator busy, WAIT
	    while(Ref_A_isRefGenBusy(REF_A_BASE));
	    //Select internal ref = 1.2V
	    Ref_A_setReferenceVoltage(REF_A_BASE, REF_A_VREF1_2V);
	    //Turn on Reference Voltage
	    Ref_A_enableReferenceVoltage(REF_A_BASE);
}

void myvref2V()
{
	 	 // Configure internal reference
	    while(Ref_A_isRefGenBusy(REF_A_BASE));              // If ref generator busy, WAIT
	    //Ref_A_enableTempSensor(REF_A_BASE);             // if i have  enable temp sensor
	    Ref_A_setReferenceVoltage(REF_A_BASE, REF_A_VREF2_0V);
	    Ref_A_enableReferenceVoltage(REF_A_BASE);

}
void myvref2_5V()
{
// Configure internal reference
             while(Ref_A_isRefGenBusy(REF_A_BASE));              // If ref generator busy, WAIT
             Ref_A_enableTempSensor(REF_A_BASE);
             Ref_A_setReferenceVoltage(REF_A_BASE, REF_A_VREF2_5V);
             Ref_A_enableReferenceVoltage(REF_A_BASE);

}


#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=ADC12_VECTOR
__interrupt
#elif defined(__GNUC__)
__attribute__((interrupt(ADC12_VECTOR)))
#endif

__interrupt void ADC12_ISR(void)
{
    switch (__even_in_range(ADC12IV, ADC12IV_ADC12RDYIFG))
    {
        case ADC12IV_NONE:        break;    // Vector  0:  No interrupt
        case ADC12IV_ADC12OVIFG:  break;    // Vector  2:  ADC12BMEMx Overflow
        case ADC12IV_ADC12TOVIFG: break;    // Vector  4:  Conversion time overflow
        case ADC12IV_ADC12HIIFG:  break;    // Vector  6:  ADC12BHI
        case ADC12IV_ADC12LOIFG:  break;    // Vector  8:  ADC12BLO
        case ADC12IV_ADC12INIFG:  break;    // Vector 10:  ADC12BIN
        case ADC12IV_ADC12IFG0:             // Vector 12:  ADC12BMEM0 Interrupt
            		ADC12IFGR0 &= ~ADC12IFG0;// Clear interrupt flag
            		// Exit active CPU
            		//__bic_SR_register_on_exit(LPM0_bits);
            		__bic_SR_register_on_exit(LPM4_bits); // Exit active CPU
            		break;

        case ADC12IV_ADC12IFG1:       // Vector 14:  ADC12BMEM1
        			ADC12IFGR0 &= ~ADC12IFG1;// Clear interrupt flag
                   // Exit active CPU
                   //__bic_SR_register_on_exit(LPM0_bits);
                   __bic_SR_register_on_exit(LPM4_bits); // Exit active CPU
                   break;
        case ADC12IV_ADC12IFG2:       // Vector 16:  ADC12BMEM2
        					ADC12IFGR0 &= ~ADC12IFG2;// Clear interrupt flag
                           // Exit active CPU
                           //__bic_SR_register_on_exit(LPM0_bits);
                           __bic_SR_register_on_exit(LPM4_bits); // Exit active CPU
                           break;
        case ADC12IV_ADC12IFG3:       // Vector 18:  ADC12BMEM3
        					ADC12IFGR0 &= ~ADC12IFG3;// Clear interrupt flag
                           // Exit active CPU
                           //__bic_SR_register_on_exit(LPM0_bits);
                           __bic_SR_register_on_exit(LPM4_bits); // Exit active CPU
                           break;
        case ADC12IV_ADC12IFG4:   break;    // Vector 20:  ADC12BMEM4
        case ADC12IV_ADC12IFG5:   break;    // Vector 22:  ADC12BMEM5
        case ADC12IV_ADC12IFG6:   break;    // Vector 24:  ADC12BMEM6
        case ADC12IV_ADC12IFG7:   break;    // Vector 26:  ADC12BMEM7
        case ADC12IV_ADC12IFG8:   break;    // Vector 28:  ADC12BMEM8
        case ADC12IV_ADC12IFG9:   break;    // Vector 30:  ADC12BMEM9
        case ADC12IV_ADC12IFG10:  break;    // Vector 32:  ADC12BMEM10
        case ADC12IV_ADC12IFG11:  break;    // Vector 34:  ADC12BMEM11
        case ADC12IV_ADC12IFG12:  break;    // Vector 36:  ADC12BMEM12
        case ADC12IV_ADC12IFG13:  break;    // Vector 38:  ADC12BMEM13
        case ADC12IV_ADC12IFG14:  break;    // Vector 40:  ADC12BMEM14
        case ADC12IV_ADC12IFG15:  break;    // Vector 42:  ADC12BMEM15
        case ADC12IV_ADC12IFG16:  break;    // Vector 44:  ADC12BMEM16
        case ADC12IV_ADC12IFG17:  break;    // Vector 46:  ADC12BMEM17
        case ADC12IV_ADC12IFG18:  break;    // Vector 48:  ADC12BMEM18
        case ADC12IV_ADC12IFG19:  break;    // Vector 50:  ADC12BMEM19
        case ADC12IV_ADC12IFG20:  break;    // Vector 52:  ADC12BMEM20
        case ADC12IV_ADC12IFG21:  break;    // Vector 54:  ADC12BMEM21
        case ADC12IV_ADC12IFG22:  break;    // Vector 56:  ADC12BMEM22
        case ADC12IV_ADC12IFG23:  break;    // Vector 58:  ADC12BMEM23
        case ADC12IV_ADC12IFG24:  break;    // Vector 60:  ADC12BMEM24
        case ADC12IV_ADC12IFG25:  break;    // Vector 62:  ADC12BMEM25
        case ADC12IV_ADC12IFG26:  break;    // Vector 64:  ADC12BMEM26
        case ADC12IV_ADC12IFG27:  break;    // Vector 66:  ADC12BMEM27
        case ADC12IV_ADC12IFG28:  break;    // Vector 68:  ADC12BMEM28
        case ADC12IV_ADC12IFG29:  break;    // Vector 70:  ADC12BMEM29
        case ADC12IV_ADC12IFG30:  break;    // Vector 72:  ADC12BMEM30
        case ADC12IV_ADC12IFG31:  break;    // Vector 74:  ADC12BMEM31
        case ADC12IV_ADC12RDYIFG: break;    // Vector 76:  ADC12BRDY
        default: break;
    }
}

/*
 * Timer0_A3 Interrupt Vector (TAIV) handler
 * Used to trigger ADC conversion every 0.125 seconds
 *
 */
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
    __bic_SR_register_on_exit(LPM3_bits); // Exit active CPU
}


/**
 * Correct RAW ADC reading according to calibration procedure
 *
 * See user guide 1.14.3.2
 *
 * @param raw RAW ADC value
 * @return corrected RAW ADC value
 */
uint16_t ADC_rawCorrection(uint16_t raw) {
    // Convert input to 32 bit to have prevent overflows
    int32_t temp = (int32_t) (0x00000000 + raw);

    // Get calibration values from TLV structure
    uint16_t adc_gain   = (uint16_t) *((uint16_t*)0x1A16);
    uint16_t adc_offset = (uint16_t) *((uint16_t*)0x1A18);

    // Correct measurement for device specific offset/gain
    temp = ((temp * adc_gain) >> 15) + adc_offset;

    // Return only the right most word
    return (uint16_t) (temp & 0xFFFF);
}

/**
 * Convert RAW ADC reading to MilliVolts.
 *
 * Based on formula (see user guide 25.2.1):
 *  Nadc = 4096 * ( (Vin + .5LSB) - Vr- ) / ( Vr+ - Vr- )  where  LSB = ( Vr+ - Vr- ) / 4096
 *
 * Formula converted to:
 *  Vin = (Nadc * ( Vr+ - Vr- ) ) / 4096 + Vr- - .5LSB  where  LSB = ( Vr+ - Vr- ) / 4096
 *
 * @param raw RAW ADC value
 * @return voltage in milli Volts (e.g. 1 ~ .001V)
 */

uint16_t ADC_rawToVoltage(uint16_t raw) {
    // ADC is configured to use VSS as Vr-
    const uint16_t v_minus = 0;

    // Get reference Voltage from settings
    ADC_referenceSelect reference = ADC_getReference();
    uint16_t v_plus = (reference == ADC_reference_1_2V) ? 1200 :
                      (reference == ADC_reference_2_0V) ? 2000 :
                      (reference == ADC_reference_2_5V) ? 2500 : 0;

    // Get ADC precision from settings
    ADC_precisionSelect precision = ADC_getPrecision();
    uint16_t factor = (precision == ADC_precision_8bit) ? 8 :
                      (precision == ADC_precision_10bit) ? 10 :
                      (precision == ADC_precision_12bit) ? 12 : 0;

    // Calculate the value of the Least Significant Bit
    uint16_t lsb = (v_plus - v_minus) >> factor;

    uint32_t temp = (uint32_t) (0x00000000 + ADC_rawCorrection(raw)); // convert RAW value to 32bit, give us some wiggle room
    temp *= (v_plus - v_minus);                   // multiply by (Vr+ - Vr-)
    temp >>= factor;                              // divide by 2^factor
    temp += v_minus;                              // add Vr-
    temp -= (lsb >> 1);                           // subtract LSB/2

    // Return only the right most word
    return (uint16_t) (temp & 0xFFFF);
}


/**
 * Get currently set voltage reference.
 */
ADC_referenceSelect ADC_getReference(void)
{
    return ADC_reference_2_0V;
}

/**
 * Get currently set conversion precision.
 */
ADC_precisionSelect ADC_getPrecision(void)
{
    return ADC_precision_12bit;
}

/**
 * Convert RAW ADC reading to milli degree Celcius.
 *
 * @param raw RAW ADC value
 * @return temperature in milli degree Celcius (e.g. 1 ~ .001C)
 */
int16_t ADC_rawToTemperature(uint16_t raw) {

    // Convert input to 32 bit to have prevent overflows
    int32_t temp = (int32_t) (0x00000000 + ADC_rawCorrection(raw));

    // Get callibration values (for 30C and 85C) from TLV structure
    ADC_referenceSelect reference = ADC_getReference();
    uint16_t adc_ref30 = (reference == ADC_reference_1_2V) ? *((uint16_t*)0x1A1A) :
                         (reference == ADC_reference_2_0V) ? *((uint16_t*)0x1A1E) :
                         (reference == ADC_reference_2_5V) ? *((uint16_t*)0x1A22) : 0;

    uint16_t adc_ref85 = (reference == ADC_reference_1_2V) ? *((uint16_t*)0x1A1C) :
                         (reference == ADC_reference_2_0V) ? *((uint16_t*)0x1A20) :
                         (reference == ADC_reference_2_5V) ? *((uint16_t*)0x1A24) : 0;

    // Linearly aproximate temperature
    temp -= adc_ref30;
    temp *= 1000;
    temp *= (85000 - 30000) / (adc_ref85 - adc_ref30);
    temp += 30000;

    // Return only the right most word
    return (int16_t) (temp & 0xFFFF);
}

void InitMyTimerA()
{											// Start timer
                	 	        	        Timer_A_initUpModeParam param = {0};
                	 	        	        param.clockSource = TIMER_A_CLOCKSOURCE_ACLK;
                	 	        	        param.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_1;
                	 	        	        param.timerPeriod = 13;
                	 	        	        param.timerInterruptEnable_TAIE = TIMER_A_TAIE_INTERRUPT_DISABLE;
                	 	        	        param.captureCompareInterruptEnable_CCR0_CCIE =TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE;
                	 	        	        param.timerClear = TIMER_A_DO_CLEAR;
                	 	        	        param.startTimer = true;
                	 	        	        Timer_A_initUpMode(TIMER_A0_BASE, &param);
                	 	        	       // Enter LPM3. Delay for Ref to settle.
                	 	        	        __bis_SR_register(LPM3_bits | GIE);

}

void getSensorData()
{

	                	                	      //Enable/Start sampling and conversion
	                	                	        /*
	                	                	         * Base address of ADC12B Module
	                	                	         * Start the conversion into memory buffer 0
	                	                	         * Use the sequential-channel,  not single-conversion mode
	                	                	         */
	                	                        //Enable/Start sampling and conversion
	                ADC12_B_startConversion(ADC12_B_BASE, //ADC12B
	                	      ADC12_B_START_AT_ADC12MEM0, //Memory Buffer 0
	                     			ADC12_B_SEQOFCHANNELS); // not SINGEL !!! be carefull ->when i have only one ADC channel is Single


	                 // Wait for conversion to complete
	                 __bis_SR_register(LPM3_bits | GIE);
	                 __bic_SR_register(GIE);

	                 //read the ADC result and store it in "data"
	                  data0 = ADC12_B_getResults(ADC12_B_BASE,ADC12_B_MEMORY_0);	  //Memory Buffer 0
	                  data1 = ADC12_B_getResults(ADC12_B_BASE,ADC12_B_MEMORY_1);      //Memory Buffer 1
	                  data2 = ADC12_B_getResults(ADC12_B_BASE,ADC12_B_MEMORY_2);      //Memory Buffer 2
	                  data3 = ADC12_B_getResults(ADC12_B_BASE,ADC12_B_MEMORY_3);      //Memory Buffer 3
	                  //calibrate ADC data
	                  CalmVolt0= ADC_rawToVoltage(data0);
	                  CalmVolt1= ADC_rawToVoltage(data1);
	                  CalmVolt2= ADC_rawToVoltage(data2);
	                  VBatt= ADC_rawToVoltage(data3)*2;

	                  //Disable ADC
	                  ADC12_B_disable(ADC12_B_BASE);
	                  //Stop the timer A
	                   Timer_A_stop(TIMER_A0_BASE);
	                   //close VDD power Supply for the sensors ->pin P1.2
	                    GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN2);
}


void CaltulateTempDif()
{
	FactorA= -1.064200E-09f;
	FactorB= -5.759725E-06f;
	FactorC= -1.789883E-01f;
	FactorD=  2.048570E+02f;

	TemporC1 = (float)FactorA*pow(CalmVolt0,3)+ (float)FactorB*pow(CalmVolt0,2)+ (float)FactorC*(CalmVolt0) + FactorD;
	TemporC2 = (float)FactorA*pow(CalmVolt1,3)+ (float)FactorB*pow(CalmVolt1,2)+ (float)FactorC*(CalmVolt1) + FactorD;
	TempDiff=TemporC2-TemporC1;
}


void createPacket(unsigned char  *txdata, int SensorID, int16_t Value)
{
	int f = 0;
	int fi = 0;

	for(fi = 0; fi<PACKETLENGTH; fi++){
		txdata[fi] = ' ';
	}

	// Create the preamble sequence (1 0 1 0 1 0....)
		for(f = 0; f<PREAMBLE_LENGTH; f++){

			if(f<6){
				if(f%2 == 0){
					txdata[f] = '1';
				}else{
					txdata[f] = '0';
				}
			}else{
							txdata[f] = '1';
						}

		}

		//myUart_writeBuf( BACKCHANNEL_UART, "***PREAMBLE BITS (16)***", NULL, CRLF );
		//myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)txdata, NULL, CRLF );
		//__delay_cycles(1000000);
		//--------------------------------------------------------------------------
		int_to_binary(txdata, (unsigned int)NODE_ID, (int)ID_LENGTH, (int)PREAMBLE_LENGTH);
		//--------------------------------------------------------------------------
		//myUart_writeBuf( BACKCHANNEL_UART, "***+NODE_ID BITS (5)***", NULL, CRLF );
		//myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)txdata, NULL, CRLF );
		//__delay_cycles(1000000);
		//--------------------------------------------------------------------------
		int_to_binary(txdata, SensorID, (int)UTILITY_LENGTH, (int)(PREAMBLE_LENGTH + ID_LENGTH));
		//--------------------------------------------------------------------------
		//myUart_writeBuf( BACKCHANNEL_UART, "***+SENSOR_ID BITS (8)***", NULL, CRLF );
		//myUart_writeBuf(BACKCHANNEL_UART, (unsigned char *)txdata, NULL, CRLF );
		//__delay_cycles(1000000);
		//--------------------------------------------------------------------------
		int_to_binary(txdata, (unsigned int)Value,INFOWORD_LENGTH, (int)(PREAMBLE_LENGTH +ID_LENGTH+UTILITY_LENGTH));
		txdata[PACKETLENGTH-1] = '1';
		int_to_binary(infodata, (unsigned int)Value, INFOWORD_LENGTH, 0);

}


void backscatter_transmit_packet(unsigned char  *txdata, unsigned char  length)
{
	int ii = 0;
	//open VDD power Supply for the rf front end  -> pin  P3.4
	GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN4);  //P3OUT =  10; //(0001 00000)

	//P4OUT =  00;
	while(ii < length){
		if(txdata[ii] == '1')//-- or __
		{
			P4OUT ^=  0x40;
			T_symbol_1MHz_1ms ();
			T_symbol_1MHz_1ms ();
		}

		if(txdata[ii] == '0') //_|- or -|_
		{

					P4OUT ^=  0x40;
					T_symbol_1MHz_1ms ();
					P4OUT ^=  0x40;
					T_symbol_1MHz_1ms ();
		}

		ii++;
	}
	//close VDD power Supply for the rf front end ->pin  P3.4
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN4); //P3OUT =  00;
}

void SendFIXEDBits(void)
{
	 //open VDD power Supply for the rf front end  -> pin P1.1
	 GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN4);
	//send message
	backscatter_transmit_packet(Mypacket,MIYFIXEDPACKETLENGTH);
	//close VDD power Supply for the rf front end ->pin P1.1
	GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN4);

}



void int_to_binary(unsigned char  *array, unsigned int value, unsigned int len,  unsigned int index)
{
		int c, k;

		for(c = len - 1; c >= 0; c--){
				k = value >> c;

				if(k & 1){
						array[index + len - c - 1] = '1';
				}else{
						array[index + len - c - 1] = '0';
				}
		}
}



void T_symbol_1MHz_200us ()
{
		int i;
		for(i = DELAY_200US;  i>0  ; i--)
		{
			  	  	  	  	  	  	  asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");


						 }
}
void T_symbol_1MHz_263us ()
{
		int i;
		for(i = DELAY_263US;  i>0  ; i--)
		{
			  	  	  	  	  	  	  asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");



						 }
}


void T_symbol_1MHz_500us ()
{
		int i;
		for(i = DELAY_500US;  i>0  ; i--)
		{
			  	  	  	  	  	  	  asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");



						 }
}

void T_symbol_1MHz_400us ()
{
		int i;
		for(i = DELAY_400US;  i>0  ; i--)
		{
			  	  	  	  	  	  	  asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");

						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop");
						 		      asm(" nop"); // 30 stathero point




						 }
}






void T_symbol_1MHz_1ms ()
{
		int i;
		for(i = DELAY_1MS;  i>0  ; i--)
		{
						  asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop"); // 30 stathero point

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
						 }
}



void T_symbol_1MHz_5ms ()
{
		int i;
		for(i = DELAY_5MS;  i>0  ; i--)
		{
						  asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop"); //29 //artios
						 }
}


void T_symbol_1MHz_10ms ()
{
		int i;
		for(i = DELAY_10MS;  i>0  ; i--)
		{
						  asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");

			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop");
			 		      asm(" nop"); //29 //artios
						 }
}

