/********************************************************************************
 * - STSM_main_v10.h															*
 * - Author: Spyridon-Nektarios Daskalakis										*
 * - Version: 10.0																*
 ********************************************************************************/
//
//
//********************************MCU SHEMATIC**********************************
//
//               MSP430FR5969
//             ---------------
//     	   /|\|           PJ.4|-XIN
//    	    | |               |  32KHz Crystal
//    	    --|RST        PJ.5|-XOUT
//      	  |               |
//  	      |               |
//      	  |           P1.5|---< ADC channel 3
//    	      |               |
///   	      |           P1.4|---< ADC channel 2 (T_air)
//     	      |               |
//  	      |           P1.3|---< ADC channel 1 (T_Leaf)
//  	      |               |
//  	      |               |
//  LED <---  |P1.0       P1.2|---> Supply sensors(VDD_sen)
//            |               |
// FREQ |---  |P4.6       P3.4|---> Supply RF Front(VDD_RF)
//  	|     |               |
//      |      ---------------
//     \|/
//  _   _   _
//   |_| |_| |_|
//------------------------------------------------------------------
// MAIN Settings
//------------------------------------------------------------------
#define NODE_ID 1								 // Node ID

#ifndef OUTOFBOX_FR5969_NEWD_MAIN_H_
#define OUTOFBOX_FR5969_NEWD_MAIN_H_

//voltage references for ADC
typedef enum {
    ADC_reference_1_2V = REFVSEL_0,
    ADC_reference_2_0V = REFVSEL_1,
    ADC_reference_2_5V = REFVSEL_2,
} ADC_referenceSelect;

/**
 * ADC precision (see user guide 25.3.3)
 */
typedef enum {
    ADC_precision_8bit = ADC12RES__8BIT,
    ADC_precision_10bit = ADC12RES__10BIT,
    ADC_precision_12bit = ADC12RES__12BIT,
} ADC_precisionSelect;


//Debug variables
extern  const int Debug_en;
extern  const int Sleep_en;
extern  int SensorID;

//Basic Functions
void InitMyADC(void);
void enterLPM35(void);
void myvref2V(void);
void InitMyTimerA(void);
void getSensorData(void);
void CaltulateTempDif(void);


//Scatter Communication
void Sympol(int nowsym);
void createPacket(unsigned char *txdata, int SensorID, int16_t Value);
void int_to_binary(unsigned char  *array, unsigned int value, unsigned int len, unsigned int index);
void SendFIXEDBits(void);
void backscatter_transmit_packet(unsigned char  *txdata, unsigned char  length);

//T_symbol functions
void T_symbol_1MHz_200us();
void T_symbol_1MHz_263us();
void T_symbol_1MHz_400us();
void T_symbol_1MHz_500us();

void T_symbol_1MHz_1ms();
void T_symbol_1MHz_5ms();
void T_symbol_1MHz_10ms();

//Calibrate ADC
ADC_referenceSelect ADC_getReference(void);
ADC_precisionSelect ADC_getPrecision(void);
uint16_t ADC_rawCorrection(uint16_t raw);
uint16_t ADC_rawToVoltage(uint16_t raw);


#endif /* OUTOFBOX_FR5969_NEWD_MAIN_H_ */



