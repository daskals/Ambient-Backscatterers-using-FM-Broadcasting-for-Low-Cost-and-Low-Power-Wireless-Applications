/********************************************************************************
 * - BackscatterCom.h																*
 * - Author: Spiros Daskalakis													*
 * - Version: 8.0																*
 ********************************************************************************/

// Packet Parameters.


#define PREAMBLE_LENGTH 10
#define ID_LENGTH 2
#define UTILITY_LENGTH 2
#define DUMMYBIT 1
#define HEADER_LENGTH (PREAMBLE_LENGTH+ID_LENGTH+UTILITY_LENGTH)

#define GEN_MATRIX_ROWS 12
//Uncoded
#define CODEWORD_LENGTH 12
#define INFOWORD_LENGTH 12

#define PACKETLENGTH (HEADER_LENGTH+INFOWORD_LENGTH+DUMMYBIT)
#define MIYFIXEDPACKETLENGTH 5

#define  DELAY_1MS 27//29 stathero
#define  DELAY_500US 18//
#define  DELAY_400US 13 //404 412
#define  DELAY_263US 9//
#define  DELAY_200US 7//

#define  DELAY_5MS 169 //prepei na einai arteio noumero
#define  DELAY_10MS 341 //prepei na einai arteio noumero

